<section class="mini" id="services">
    <div class="mini-content">
        <div class="container">
            <div class="row">
                <div class="offset-lg-3 col-lg-6">
                    <div class="info">
                        <h1>Nuestra Línea de Negocio</h1>
                        <p>Calidad y responsabilidad nos respaldan.</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.miniCard','data' => []]); ?>
<?php $component->withName('miniCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('image', null, []); ?> img/web.png <?php $__env->endSlot(); ?>
                     <?php $__env->slot('title', null, []); ?> DESARROLLO WEB <?php $__env->endSlot(); ?>
                     <?php $__env->slot('description', null, []); ?> Desarrollamos acorde a las tecnologías más escalables en el mercado,
                        teniendo en cuenta la Experiencia de Usuario como base para brindar un producto
                        que cumpla con las expectativas. <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.miniCard','data' => []]); ?>
<?php $component->withName('miniCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('image', null, []); ?> img/movil.png <?php $__env->endSlot(); ?>
                     <?php $__env->slot('title', null, []); ?> DESARROLLO MÓVIL <?php $__env->endSlot(); ?>
                     <?php $__env->slot('description', null, []); ?> 
                        Aplicaciones Multiplataformas con el objetivo
                        de brindar un alcance masivo a tu empresa y facilitar la conexión con tus clientes
                        y empleados.
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.miniCard','data' => []]); ?>
<?php $component->withName('miniCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('image', null, []); ?> img/server.png <?php $__env->endSlot(); ?>
                     <?php $__env->slot('title', null, []); ?> SERVIDORES <?php $__env->endSlot(); ?>
                     <?php $__env->slot('description', null, []); ?> 
                        Servicio calificado para el alojamiento de tu información, déjanos
                        hacerlo por ti de forma segura y darte la tranquilidad de saber que tu información
                        está en un espacio seguro.
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.miniCard','data' => []]); ?>
<?php $component->withName('miniCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('image', null, []); ?> img/videoGame.png <?php $__env->endSlot(); ?>
                     <?php $__env->slot('title', null, []); ?> DESARROLLO DE VIDEOJUEGOS <?php $__env->endSlot(); ?>
                     <?php $__env->slot('description', null, []); ?> 
                        Creación de videojuegos que cumplen tus expectativas, plasmando tus ideas para dar vida
                        a mundos virtuales llenos de diversión y entretenimiento.
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
            <!-- ***** Mini Box End ***** -->
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\landingdevzeros\resources\views/layouts/services.blade.php ENDPATH**/ ?>