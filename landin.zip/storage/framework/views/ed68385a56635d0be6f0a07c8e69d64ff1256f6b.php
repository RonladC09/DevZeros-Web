 <div class="col-lg-3 col-md-6 col-sm-6 col-12" style="display: flex; justify-content: center">
    <a href="#" class="mini-box">
        <i><img class="Service-img" src="<?php echo e($image); ?>" alt=""></i>
        <strong><?php echo e($title); ?></strong>
        <span><?php echo e($description); ?>.</span>
    </a>
</div>
<?php /**PATH C:\laragon\www\landingdevzeros\resources\views/components/miniCard.blade.php ENDPATH**/ ?>