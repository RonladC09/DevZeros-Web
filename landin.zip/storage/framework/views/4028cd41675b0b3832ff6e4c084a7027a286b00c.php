<article class="hero">
    <div class="welcome-area bg-hero" id="welcome">

        <!-- ***** Header Text Start ***** -->
        <div class="header-text">
            <div class="container">
                <div class="row">
                    <div class="offset-xl-3 col-xl-6 offset-lg-2 col-lg-10 col-md-12 col-sm-12">
                        <h1>INOVACIÓN DE<strong> HOY</strong><br>PARA EL EXITO DEL<strong> MAÑANA</strong></h1>
                        <p>Somos una empresa dedicada a las Soluciones Tecnológicas que se presenta en los distintos
                            sectores del comercio nacional e internacional.</p>
                        <div>
                            <img src="img/hero.gif" alt="hero">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ***** Header Text End ***** -->
    </div>
    <section class="section home-feature">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <!-- ***** Features Small Item Start ***** -->
                    </div>
                </div>
            </div>
        </div>
    </section>
</article>

<?php /**PATH C:\laragon\www\landingdevzeros\resources\views/layouts/hero.blade.php ENDPATH**/ ?>