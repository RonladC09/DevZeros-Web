<div class="col-lg-3 col-md-6 col-sm-12">
    <div class="team-item">
        <div class="team-content">
            <i><img src="<?php echo e($image); ?>" alt=""></i>
            <div class="team-info">
                <h3 class="user-name"><?php echo e($user); ?></h3>
                <span><?php echo e($profession); ?></span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\landingdevzeros\resources\views/components/testimonialCards.blade.php ENDPATH**/ ?>