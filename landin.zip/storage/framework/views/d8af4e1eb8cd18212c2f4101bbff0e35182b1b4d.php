<div class="col-lg-4 col-md-6 col-sm-12" data-scroll-reveal="enter bottom move 50px over 0.6s after 0.2s">
    <div class="pricing-item active">
        <div class="pricing-header">
            <img src="<?php echo e($img); ?>" class="pricing-title" alt=""/>
        </div>
        <div class="pricing-body">
            <div class="price-wrapper">
                <span class="price"><?php echo e($price); ?></span>
            </div>
            <ul class="list">
                <li><?php echo e($text); ?></li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\landingdevzeros\resources\views/components/pricing.blade.php ENDPATH**/ ?>