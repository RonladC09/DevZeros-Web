var content = document.querySelector("#content-carousel");
var speed = 1; // velocidad de desplazamiento en píxeles por cuadro
var distance = 0;
var frame;

// agregamos una copia del contenido al final del carrusel
var contentCopy = content.cloneNode(true);
content.appendChild(contentCopy);

function startCarousel() {
    frame = requestAnimationFrame(startCarousel);
    distance -= speed;
    content.style.transform = "translateX(" + distance + "px)";

    if (distance % 1000 == 0) {
        var firstImg = content.children[0];
        content.removeChild(firstImg);
        content.appendChild(firstImg);
        distance = 0;
    }
}

// iniciamos el carrusel al cargar la página
startCarousel();
