<section class="section colored" id="methodology">
    <div class="container">
        <!-- ***** Section Title Start ***** -->
        <div class="row">
            <div class="col-lg-12">
                <div class="center-heading">
                    <h2 class="section-title">Metodología de Trabajo</h2>
                </div>
            </div>
            <div class="offset-lg-3 col-lg-6">
                <div class="center-text">
                    <p>Somos un grupo apasionado de <b>Desarrolladores</b> que nos interesa convertir tu idea
                        en un sueño cumplido.</p>
                </div>
            </div>
        </div>
        <!-- ***** Section Title End ***** -->

        <div class="row">
            <!-- ***** Pricing Item Start ***** -->
            <x-pricing>
                <x-slot name="img">img/acelerar.svg</x-slot>
                <x-slot name="price">Acelear</x-slot>
                <x-slot name="text">Acelerar los procesos para satisfacer al cliente.</x-slot>
            </x-pricing>
            <!-- ***** Pricing Item End ***** -->

            <!-- ***** Pricing Item Start ***** -->
            <x-pricing>
                <x-slot name="img">img/Actuar.svg</x-slot>
                <x-slot name="price">Actuar</x-slot>
                <x-slot name="text">Actuar con rapidez ante los posibles cambios.</x-slot>
            </x-pricing>
            <!-- ***** Pricing Item End ***** -->

            <x-pricing>
                <x-slot name="img">img/realizar.svg</x-slot>
                <x-slot name="price">realizar</x-slot>
                <x-slot name="text">Realizar entregas periódicas del trabajo.</x-slot>
            </x-pricing>
        </div>
    </div>
</section>
