<section class="counter">
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="count-item decoration-bottom">
                        <strong>126</strong>
                        <span>Projects</span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="count-item decoration-top">
                        <strong>63</strong>
                        <span>Happy Clients</span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="count-item decoration-bottom">
                        <strong>18</strong>
                        <span>Awards Wins</span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="count-item">
                        <strong>27</strong>
                        <span>Countries</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
