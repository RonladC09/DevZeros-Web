<div class="col-lg-4 col-md-6 col-sm-12" data-scroll-reveal="enter bottom move 50px over 0.6s after 0.2s">
    <div class="pricing-item active">
        <div class="pricing-header">
            <img src="{{$img}}" class="pricing-title" alt=""/>
        </div>
        <div class="pricing-body">
            <div class="price-wrapper">
                <span class="price">{{$price}}</span>
            </div>
            <ul class="list">
                <li>{{$text}}</li>
            </ul>
        </div>
    </div>
</div>
