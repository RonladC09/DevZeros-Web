<div class="col-lg-3 col-md-6 col-sm-12">
    <div class="team-item">
        <div class="team-content">
            <i><img src="{{$image}}" alt=""></i>
            <div class="team-info">
                <h3 class="user-name">{{$user}}</h3>
                <span>{{$profession}}</span>
            </div>
        </div>
    </div>
</div>
